from multiprocessing.dummy import Pool
import requests
import json
import socket
import pyfiglet
from ansi.colour import fg, bg
class Reverse_IP():
    def banner(self):
        b = "BACOT"
        gr = "2022"
        pyfiglet.print_figlet(b,'rounded')
        print("\n" + gr)

    def revip(self,ip):
        domain = requests.get(f"https://tr0yacrew.herokuapp.com/rev/1/{ip}")
        j = (domain.text)
        hasil = open("results.txt", "a").write(domain.text)

# tulis teks ke file
        

    
    def cut(self, ip='',leng=False):
            if leng == False:
                ret = ip
            else:
                length_string = len(ip)
                if length_string > leng:
                    ret = ip[0:leng]
                else:
                  nephi = leng-length_string
                  ret = ip+' '*nephi
            return str(ret)
                    
try:
    rev = Reverse_IP()
    rev.banner()
    ip = [i.strip() for i in open(str(input("List : "))).readlines()]
    thr = Pool(int(input("Thread: ")))
    thr.map(rev.revip,ip)
except IOError:
    print(fg.red("File Not Found"))
except FileNotFoundError:
    print(fg.red("File Not Found"))
except KeyboardInterrupt:
    print(fg.red("Keyboard Interrupt Detected"))
