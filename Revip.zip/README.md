### How to use
> Install python & git
```
apt install python
apt install git
git clone https://github.com/DK77-sys/Revip
cd Revip
```
> Install Module
```
pip3 install requests
```
> Run Tools
```
python3 rev.py
```
This tool works only python3 Version
